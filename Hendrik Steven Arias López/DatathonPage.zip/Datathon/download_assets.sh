#!/bin/bash

# Nombre del bucket (reemplaza con tu bucket)
BUCKET_NAME="tu-proyecto-datos"

# Descargar datos y modelo de GCS
echo "Descargando assets desde gs://${BUCKET_NAME}/..."

# Asegurar que los directorios existen
mkdir -p data models

# Descargar archivos
gsutil cp gs://${BUCKET_NAME}/data.csv ./data/ || echo "No se encontró data.csv"
gsutil cp gs://${BUCKET_NAME}/model.joblib ./models/ || echo "No se encontró model.joblib"
gsutil cp gs://${BUCKET_NAME}/scaler.joblib ./models/ || echo "No se encontró scaler.joblib"

echo "Assets descargados exitosamente" 