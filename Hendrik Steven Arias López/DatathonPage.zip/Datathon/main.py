import firebase_functions as functions
from flask import Flask, render_template, request, jsonify
import pandas as pd
import numpy as np
import os
from werkzeug.utils import secure_filename
import tempfile

app = Flask(__name__)

# Configuración para archivos temporales
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max file size

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        return jsonify({'error': 'No se encontró ningún archivo'}), 400
    
    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'No se seleccionó ningún archivo'}), 400
    
    if file and file.filename.endswith('.csv'):
        # Crear un archivo temporal
        with tempfile.NamedTemporaryFile(delete=False, suffix='.csv') as temp_file:
            file.save(temp_file.name)
            try:
                # Procesar el CSV
                df = pd.read_csv(temp_file.name)
                # Aquí puedes agregar tu lógica de predicción
                
                # Limpiar el archivo temporal
                os.unlink(temp_file.name)
                
                return jsonify({
                    'message': 'Archivo procesado correctamente',
                    'preview': df.head().to_dict(),
                    # 'predictions': predictions  # Descomenta cuando agregues el modelo
                })
            except Exception as e:
                # Asegurarse de limpiar el archivo temporal en caso de error
                os.unlink(temp_file.name)
                return jsonify({'error': f'Error al procesar el archivo: {str(e)}'}), 500
    
    return jsonify({'error': 'Tipo de archivo no permitido'}), 400

# Exportar la función para Firebase
app = functions.https.on_request(app) 