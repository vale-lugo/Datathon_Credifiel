// Configuración de colores y estilos
const colors = {
    primary: '#2C3E50',
    secondary: '#34495E',
    accent: '#3498DB',
    success: '#2ECC71',
    warning: '#F1C40F',
    danger: '#E74C3C',
    light: '#ECF0F1',
    dark: '#2C3E50'
};

// Datos de ejemplo (esto se reemplazará con datos reales de la API)
let chartData = {
    trends: {
        labels: ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun'],
        datasets: [{
            label: 'Ventas 2022',
            data: [65, 59, 80, 81, 56, 55],
            borderColor: colors.primary,
            tension: 0.4
        }, {
            label: 'Ventas 2023',
            data: [28, 48, 40, 19, 86, 27],
            borderColor: colors.accent,
            tension: 0.4
        }]
    },
    distribution: {
        labels: ['Categoría A', 'Categoría B', 'Categoría C', 'Categoría D'],
        datasets: [{
            data: [30, 25, 25, 20],
            backgroundColor: [
                colors.primary,
                colors.accent,
                colors.success,
                colors.warning
            ]
        }]
    },
    predictions: {
        labels: ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun'],
        datasets: [{
            label: 'Real',
            data: [65, 59, 80, 81, 56, 55],
            borderColor: colors.primary,
            tension: 0.4
        }, {
            label: 'Predicción',
            data: [70, 62, 75, 85, 60, 58],
            borderColor: colors.accent,
            borderDash: [5, 5],
            tension: 0.4
        }]
    },
    comparison: {
        labels: ['2022', '2023', '2024', '2025'],
        datasets: [{
            label: 'Ventas',
            data: [100, 120, 140, 160],
            backgroundColor: colors.primary
        }, {
            label: 'Clientes',
            data: [80, 95, 110, 125],
            backgroundColor: colors.accent
        }]
    }
};

// Inicialización de gráficas
let charts = {};

function initializeCharts() {
    // Gráfica de Tendencias
    charts.trend = new Chart(document.getElementById('trendChart'), {
        type: 'line',
        data: chartData.trends,
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'top',
                },
                title: {
                    display: false
                }
            },
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });

    // Gráfica de Distribución
    charts.distribution = new Chart(document.getElementById('distributionChart'), {
        type: 'doughnut',
        data: chartData.distribution,
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'right'
                }
            }
        }
    });

    // Gráfica de Predicciones
    charts.prediction = new Chart(document.getElementById('predictionChart'), {
        type: 'line',
        data: chartData.predictions,
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'top'
                }
            },
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });

    // Gráfica de Comparativa
    charts.comparison = new Chart(document.getElementById('comparisonChart'), {
        type: 'bar',
        data: chartData.comparison,
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'top'
                }
            },
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
}

// Función para aplicar filtros
function applyFilters() {
    const analysisType = document.getElementById('analysisType').value;
    const category = document.getElementById('category').value;

    // Aquí se implementará la lógica para filtrar los datos
    // Por ahora solo mostraremos un mensaje
    console.log('Aplicando filtros:', { analysisType, category });

    // TODO: Implementar la llamada a la API para obtener datos filtrados
    // fetch('/api/filtered-data', {
    //     method: 'POST',
    //     headers: {
    //         'Content-Type': 'application/json',
    //     },
    //     body: JSON.stringify({ analysisType, category })
    // })
    // .then(response => response.json())
    // .then(data => updateCharts(data));
}

// Función para actualizar las gráficas con nuevos datos
function updateCharts(newData) {
    // Actualizar cada gráfica con los nuevos datos
    Object.keys(charts).forEach(chartKey => {
        if (newData[chartKey]) {
            charts[chartKey].data = newData[chartKey];
            charts[chartKey].update();
        }
    });
}

// Función para cargar datos iniciales
async function loadInitialData() {
    try {
        // TODO: Implementar la llamada a la API para obtener datos iniciales
        // const response = await fetch('/api/initial-data');
        // const data = await response.json();
        // updateCharts(data);
        
        // Por ahora usamos los datos de ejemplo
        updateCharts(chartData);
    } catch (error) {
        console.error('Error al cargar datos:', error);
        showError('No se pudieron cargar los datos. Por favor, intente nuevamente.');
    }
}

// Función para mostrar errores
function showError(message) {
    // Implementar un sistema de notificaciones
    alert(message);
}

// Inicializar el dashboard cuando el DOM esté listo
document.addEventListener('DOMContentLoaded', () => {
    initializeCharts();
    loadInitialData();
}); 