// Variables globales
let selectedFile = null;

// Inicialización cuando el DOM está listo
document.addEventListener('DOMContentLoaded', () => {
    initializeDragAndDrop();
    setupYearValidation();
});

// Configuración del drag and drop
function initializeDragAndDrop() {
    const dropZone = document.getElementById('dropZone');
    const fileInput = document.getElementById('fileInput');

    ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
        dropZone.addEventListener(eventName, preventDefaults, false);
    });

    function preventDefaults(e) {
        e.preventDefault();
        e.stopPropagation();
    }

    ['dragenter', 'dragover'].forEach(eventName => {
        dropZone.addEventListener(eventName, highlight, false);
    });

    ['dragleave', 'drop'].forEach(eventName => {
        dropZone.addEventListener(eventName, unhighlight, false);
    });

    function highlight(e) {
        dropZone.classList.add('highlight');
    }

    function unhighlight(e) {
        dropZone.classList.remove('highlight');
    }

    dropZone.addEventListener('drop', handleDrop, false);
    fileInput.addEventListener('change', handleFileSelect, false);
}

// Manejo de archivos
function handleDrop(e) {
    const dt = e.dataTransfer;
    const files = dt.files;
    handleFiles(files);
}

function handleFileSelect(e) {
    const files = e.target.files;
    handleFiles(files);
}

function handleFiles(files) {
    if (files.length > 0) {
        const file = files[0];
        if (file.name.match(/\.(xlsx|xls|csv)$/)) {
            selectedFile = file;
            showFileInfo(file);
            document.getElementById('uploadButton').disabled = false;
        } else {
            showError('Por favor, selecciona un archivo Excel o CSV válido');
        }
    }
}

function showFileInfo(file) {
    const fileInfo = document.getElementById('fileInfo');
    const fileName = document.getElementById('fileName');
    fileName.textContent = `${file.name} (${formatFileSize(file.size)})`;
    fileInfo.classList.remove('d-none');
}

function formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

// Validación de años
function setupYearValidation() {
    const startYear = document.getElementById('startYear');
    const endYear = document.getElementById('endYear');

    startYear.addEventListener('change', validateYears);
    endYear.addEventListener('change', validateYears);
}

function validateYears() {
    const startYear = parseInt(document.getElementById('startYear').value);
    const endYear = parseInt(document.getElementById('endYear').value);

    if (startYear > endYear) {
        showError('El año inicial no puede ser mayor que el año final');
        return false;
    }
    return true;
}

// Análisis de datos existentes
async function analyzeExistingData() {
    if (!validateYears()) {
        return;
    }

    const startYear = document.getElementById('startYear').value;
    const endYear = document.getElementById('endYear').value;

    showLoading();

    try {
        const response = await fetch(`/api/initial-data?start_year=${startYear}&end_year=${endYear}`);
        const data = await response.json();

        if (response.ok) {
            // Redirigir al dashboard con los parámetros de años
            window.location.href = `/dashboard?start_year=${startYear}&end_year=${endYear}`;
        } else {
            showError(data.error || 'Error al procesar los datos');
        }
    } catch (error) {
        showError('Error de conexión. Por favor, intente nuevamente.');
    } finally {
        hideLoading();
    }
}

// Carga de archivo
async function uploadFile() {
    if (!selectedFile) {
        showError('Por favor, selecciona un archivo');
        return;
    }

    if (!validateYears()) {
        return;
    }

    const formData = new FormData();
    formData.append('file', selectedFile);
    formData.append('start_year', document.getElementById('startYear').value);
    formData.append('end_year', document.getElementById('endYear').value);

    showLoading();

    try {
        const response = await fetch('/upload', {
            method: 'POST',
            body: formData
        });

        const data = await response.json();

        if (response.ok) {
            // Redirigir al dashboard con los parámetros de años
            const startYear = document.getElementById('startYear').value;
            const endYear = document.getElementById('endYear').value;
            window.location.href = `/dashboard?start_year=${startYear}&end_year=${endYear}`;
        } else {
            showError(data.error || 'Error al procesar el archivo');
        }
    } catch (error) {
        showError('Error de conexión. Por favor, intente nuevamente.');
    } finally {
        hideLoading();
    }
}

// Utilidades de UI
function showLoading() {
    document.getElementById('loadingOverlay').classList.remove('d-none');
}

function hideLoading() {
    document.getElementById('loadingOverlay').classList.add('d-none');
}

function showError(message) {
    const alert = document.createElement('div');
    alert.className = 'alert alert-danger alert-dismissible fade show';
    alert.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    `;
    
    const container = document.querySelector('.container');
    container.insertBefore(alert, container.firstChild);

    // Auto-cerrar después de 5 segundos
    setTimeout(() => {
        alert.remove();
    }, 5000);
} 